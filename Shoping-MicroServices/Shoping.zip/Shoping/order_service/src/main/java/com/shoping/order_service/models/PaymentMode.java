package com.shoping.order_service.models;

public enum PaymentMode {
    CASH,
    PAY_PAL,
    CREDIT_CARD,
    DEBIT_CARD,
    APPLE_PAY,
    PHONE_PAY,
    CRED,
    PAYTM,
    POP,
    OTHER
}
